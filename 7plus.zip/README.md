7plus
=====

Improving windows, one by one